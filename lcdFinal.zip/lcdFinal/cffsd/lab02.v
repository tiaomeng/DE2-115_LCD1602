module lab02(
	input CLOCK_50,	//50MHz时钟
	input KEY0,	//复位按钮
	input KEY1,
	input KEY2,
	input KEY3,
	input [17:0] SW,	//开关

	//LCD接口
	output LCD_EN,
	output LCD_RS,
	output LCD_RW,
	output [7:0] LCD_DATA,

	output LCD_ON,
	output LCD_BLON
);

assign LCD_ON   = 1'b1;
assign LCD_BLON = 1'b1;
assign LCD_RW   = 1'b0;

reg lcd_en;	//LCD使能
reg lcd_rs;	//LCD数据/命令选择
reg [7:0] lcd_data;	//LCD数据

assign LCD_EN   = lcd_en;
assign LCD_RS   = lcd_rs;
assign LCD_DATA = lcd_data;

reg [31:0] cnt;	//延时计数器
reg [5:0] state;	// 状态机

//延时参数
parameter PWR_DELAY = 2500000;
parameter CMD_DELAY = 250000;  	
parameter E_DELAY   = 100;	


parameter LINE1 = "HELLO";	// 第一行显示内容
parameter LINE1_LEN = 5;	//第一行字符长度
parameter LINE2 = "WORLD";	// 第二行显示内容
parameter LINE2_LEN = 5;	//第一行字符长度


//字符缓存
reg [7:0] line1_array [0:15];
reg [7:0] line2_array [0:15];
integer i;

reg [3:0] display_mode;	//当前目标显示模式
reg [3:0] current_mode;	//当前LCD已显示模式
//按钮边沿检测变量
reg key1_last;
reg key2_last;
reg key3_last;

reg[25:0] refresh_cnt;	//刷新延时
reg[3:0] cursor_pos;	//位置变量，用于mode5
reg refresh_req;	//刷新请求

integer char_idx;	//当前发送字符索引

//显示内容生成模块
//根据display_mode的值实时生成line_array
always @(*)begin

	//默认输出为全空格
	for(i=0;i<16;i=i+1)begin
		line1_array[i] = " ";
		line2_array[i] = " ";
	end
	
	case(display_mode)	//模式选择
	
	0:begin
	line1_array[0]="H";
	line1_array[1]="E";
	line1_array[2]="L";
	line1_array[3]="L";
	line1_array[4]="O";
	line2_array[0]="W";
	line2_array[1]="O";
	line2_array[2]="R";
	line2_array[3]="L";
	line2_array[4]="D";
	end
	
	1:begin
	line1_array[0]<="s";
	line1_array[1]<="t";
	line1_array[2]<="a";
	line1_array[3]<="t";
	line1_array[4]<="e";
	line1_array[5]<=":";
	line2_array[0]<="K";
	line2_array[1]<="E";
	line2_array[2]<="Y";
	line2_array[3]<="1";
	line2_array[4]<=" ";
	line2_array[5]<="p";
	line2_array[6]<="u";
	line2_array[7]<="s";
	line2_array[8]<="h";
	end
	
	2:begin
	line1_array[0]<="s";
	line1_array[1]<="t";
	line1_array[2]<="a";
	line1_array[3]<="t";
	line1_array[4]<="e";
	line1_array[5]<=":";
	line2_array[0]<="K";
	line2_array[1]<="E";
	line2_array[2]<="Y";
	line2_array[3]<="2";
	line2_array[4]<=" ";
	line2_array[5]<="p";
	line2_array[6]<="u";
	line2_array[7]<="s";
	line2_array[8]<="h";
	end
	
	3:begin
	line1_array[0]<="s";
	line1_array[1]<="t";
	line1_array[2]<="a";
	line1_array[3]<="t";
	line1_array[4]<="e";
	line1_array[5]<=":";
	line2_array[0]<="K";
	line2_array[1]<="E";
	line2_array[2]<="Y";
	line2_array[3]<="3";
	line2_array[4]<=" ";
	line2_array[5]<="p";
	line2_array[6]<="u";
	line2_array[7]<="s";
	line2_array[8]<="h";
	end
	
	4:begin	//mode4：实时显示sw状态
		for(i=0;i<15;i=i+1)
		line1_array[i] = SW[17-i] ? "1" : "0";
		//line1_array[0]<="t";	//测试代码
		//line1_array[1]<="e";
		//line1_array[2]<="s";
		//line1_array[3]<="t";
	end
	
	5:begin	//mode5：光标移动
		for(i=0;i<16;i=i+1)
			line1_array[i] = "0";
		
		line1_array[cursor_pos] = "1";
		line2_array[cursor_pos] = "^";
	end
	
	endcase
end

//主控制状态机
//功能：1.检测按键。2.更新显示模式。3.执行LCD初始化。4.执行LCD字符写入。5.处理刷新请求
always @(posedge CLOCK_50 or negedge KEY0)
begin
	if(!KEY0) begin	//复位
		state <= 0;
		cnt <= 0;
		lcd_en <= 0;
		lcd_rs <= 0;
		lcd_data <= 0;
		char_idx <= 0;
		display_mode <= 0;
		current_mode <= 0;
	end
	else begin
		//按键边沿检测
		key1_last <= KEY1;
		key2_last <= KEY2;
		key3_last <= KEY3;
		//key下降沿检测
		if(key1_last && !KEY1)
			display_mode <=1;
		if(key2_last && !KEY2)
			display_mode <=2;
		if(key3_last && !KEY3)
			display_mode <=3;

		//若sw0拨上，则切换至mode4
		if(SW[0])
			display_mode<=4;
		else if(display_mode ==4)
			display_mode <=0;
		
		//若sw1拨上，则切换至mode5
		if(SW[1])
			display_mode<=5;
			
		if(display_mode ==5)begin
			//key2按下，光标右移
			if(key2_last&&!KEY2)begin
				if(cursor_pos<15)
					cursor_pos<=cursor_pos+1;
				refresh_req<=1;
			end
			//key3按下，光标左移
			if(key3_last&&!KEY3)begin
				if(cursor_pos>0)
					cursor_pos<=cursor_pos-1;
				refresh_req<=1;
			end
		end

		//LCD状态机
		case(state)

			//state1~12：LCD初始化

			//上电延时
			0: begin
				if(cnt < PWR_DELAY) cnt <= cnt + 1;
				else begin cnt<=0; state<=1; end
			end

			// Function Set 38h
			1: begin lcd_rs<=0; lcd_data<=8'h38; lcd_en<=1; cnt<=0; state<=2; end
			2: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=3; end end
			3: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; state<=4; end end

			// Display ON
			4: begin lcd_rs<=0; lcd_data<=8'h0C; lcd_en<=1; cnt<=0; state<=5; end
			5: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=6; end end
			6: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; state<=7; end end

			// Clear
			7: begin lcd_rs<=0; lcd_data<=8'h01; lcd_en<=1; cnt<=0; state<=8; end
			8: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=9; end end
			9: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; state<=10; end end

			// Entry Mode
			10: begin lcd_rs<=0; lcd_data<=8'h06; lcd_en<=1; cnt<=0; state<=11; end
			11: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=12; end end
			12: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; state<=13; end end

			//写第一行
			13: begin lcd_rs<=0; lcd_data<=8'h80; lcd_en<=1; cnt<=0; char_idx<=0; state<=14; end
			14: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=15; end end
			15: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; state<=16; end end

			//发送第一行字符
			16: begin
				if(char_idx < 16) begin
					lcd_rs<=1;
					lcd_data<=line1_array[char_idx];
					lcd_en<=1;
					cnt<=0;
					state<=17;
				end else begin
					char_idx<=0;
					state<=20; // 跳转第二行
				end
			end
			17: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=18; end end
			18: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; state<=19; end end
			19: begin char_idx<=char_idx+1; state<=16; end

			//写第二行
			20: begin lcd_rs<=0; lcd_data<=8'hC0; lcd_en<=1; cnt<=0; state<=21; end
			21: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=22; end end
			22: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; state<=23; end end

			// 发送第二行字符
			23: begin
				if(char_idx < 16) begin
					lcd_rs<=1;
					lcd_data<=line2_array[char_idx];
					lcd_en<=1;
					cnt<=0;
					state<=24;
				end else state<=25;
			end
			24: begin if(cnt<E_DELAY) cnt<=cnt+1; else begin lcd_en<=0; cnt<=0; state<=26; end end
			26: begin if(cnt<CMD_DELAY) cnt<=cnt+1; else begin cnt<=0; char_idx<=char_idx+1; state<=23; end end

			//等待刷新
			25:begin
				//模式变化时重新刷新LCD
				if(display_mode != current_mode)begin
					current_mode <= display_mode;
					refresh_cnt <= 0;
					state <= 7;
				end
				
				//mode5刷新请求
				else if(refresh_req)begin
					refresh_req<=0;
					state<=7;
				end
				
				//mode4定时刷新
				else if(display_mode == 4)begin
					if(refresh_cnt <=50000000)
						refresh_cnt <= refresh_cnt +1;
					else begin
						refresh_cnt <= 0;
						state<=7;
					end
				end
				else
					state<=25;
			end

			default: state<=0;
		endcase
	end
end

endmodule